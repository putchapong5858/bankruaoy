# -*- coding: utf-8 -*-
"""แคปหน้าใดหน้าหนึ่งจากไฟล์ HTML ที่สร้างไว้ เพื่อตรวจด้วยตา
   ใช้:  python3 shot.py <โฟลเดอร์ out> <ชื่อไฟล์:หน้า> ...
"""
import pathlib
import sys

from playwright.sync_api import sync_playwright

out = pathlib.Path(sys.argv[1])
jobs = [a.rsplit(":", 1) for a in sys.argv[2:]]

with sync_playwright() as pw:
    br = pw.chromium.launch()
    pg = br.new_page(viewport={"width": 794, "height": 1123})
    pg.emulate_media(media="print")
    for stem, idx in jobs:
        pg.goto((out / f"{stem}.html").resolve().as_uri())
        pg.wait_for_timeout(500)
        el = pg.query_selector_all("section.page")[int(idx)]
        p = out / f"_s_{stem}_{idx}.png"
        el.screenshot(path=str(p))
        print(p)
    br.close()
