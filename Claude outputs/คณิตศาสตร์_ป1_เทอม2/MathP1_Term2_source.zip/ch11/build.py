# -*- coding: utf-8 -*-
"""สร้าง PDF ทั้งหมดของบทที่ 11 การวัดความยาว"""
import pathlib
import sys

HERE = pathlib.Path(__file__).parent
sys.path.insert(0, str(HERE.parent))
sys.path.insert(0, str(HERE))

import engine                                         # noqa: E402
import exams                                          # noqa: E402
import sheets                                         # noqa: E402

CH = "บทที่ 11 การวัดความยาว"
SCOPE = ("เปรียบเทียบความยาวด้วยคำว่า ยาวกว่า สั้นกว่า สูงกว่า เตี้ยกว่า เท่ากัน · วัดและเปรียบเทียบความยาวหน่วยเซนติเมตรและเมตร · โจทย์ปัญหาการบวกการลบเกี่ยวกับความยาว")

if __name__ == "__main__":
    engine.run(HERE, CH, "MathP1_C11", SCOPE, sheets, exams)
