# -*- coding: utf-8 -*-
"""ตรวจงานบทที่ 10 จำนวนนับ 21 ถึง 100 ก่อนส่งครู"""
import pathlib
import sys

HERE = pathlib.Path(__file__).parent
sys.path.insert(0, str(HERE.parent))
sys.path.insert(0, str(HERE))

import check                                          # noqa: E402
import exams                                          # noqa: E402
import sheets                                         # noqa: E402

check.check_mc(exams.SETS_MC, 20)
check.check_sa(exams.SETS_SA, 10)
check.check_sheets(sheets.FORMS)
check.check_pdfs(HERE / "out")
check.check_print_spec(HERE / "out", "MathP1_C10_MC_1")
sys.exit(1 if check.done() else 0)
