# -*- coding: utf-8 -*-
"""สร้าง PDF ทั้งหมดของบทที่ 10 จำนวนนับ 21 ถึง 100"""
import pathlib
import sys

HERE = pathlib.Path(__file__).parent
sys.path.insert(0, str(HERE.parent))
sys.path.insert(0, str(HERE))

import engine                                         # noqa: E402
import exams                                          # noqa: E402
import sheets                                         # noqa: E402

CH = "บทที่ 10 จำนวนนับ 21 ถึง 100"
SCOPE = ("บอกจำนวนและแสดงจำนวน 21–100 · อ่านเขียนเลขฮินดูอารบิก เลขไทย ตัวหนังสือ · เปรียบเทียบและเรียงลำดับ · แบบรูปเพิ่มลดทีละ 1 และทีละ 10")

if __name__ == "__main__":
    engine.run(HERE, CH, "MathP1_C10", SCOPE, sheets, exams)
