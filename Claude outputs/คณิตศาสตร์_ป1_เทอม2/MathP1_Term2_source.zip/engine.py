# -*- coding: utf-8 -*-
"""เครื่องสร้างเอกสารกลาง ใช้ร่วมกันทุกบทของคณิตศาสตร์ ป.1 เทอม 2

แต่ละบทเตรียมแค่เนื้อหา (sheets.py + exams.py) แล้วเรียก run() ไฟล์เดียว
  · ใบงาน 1 รูปแบบ = 4 หน้าเด็ก + 1 หน้าเฉลยครู (มีเส้นประให้ตัด)
  · ปรนัย 1 ชุด   = โจทย์ 20 ข้อ + หน้าเฉลยพร้อมคำอธิบาย
  · อัตนัย 1 ชุด  = โจทย์ 10 ข้อ + หน้าแนวคำตอบสำหรับครู

การแบ่งหน้า วัดความสูงจริงของหัวกระดาษ คำชี้แจง และท้ายกระดาษก่อน
แล้วเติมข้อลงหน้าให้เต็มจากหน้าแรกลงไป หน้าที่ยังเหลือที่ว่าง
กล่องข้อจะยืดเองด้วย flex-grow เด็ก ป.1 จะได้มีที่เขียนกว้าง ๆ
"""
import json
import pathlib

from layout import doc, head, th, L4, opts4

GLUE = "^"                       # ฉาก = "^" แปลว่าใช้ฉากของข้อก่อนหน้า
GLUEP = "+"                      # ฉากขึ้นต้นด้วย "+" แปลว่ามีฉากของตัวเอง
#                                  แต่ต้องอยู่หน้าเดียวกับข้อก่อนหน้า


def scene_html(s):
    if not s or s == GLUE:
        return ""
    return s[1:] if s.startswith(GLUEP) else s


def is_glued(s):
    return bool(s) and (s == GLUE or s.startswith(GLUEP))


LIMIT = 945                      # ความสูงใช้งานจริงของ .page (250 มม.)
GAP = 9                          # margin-bottom ของ .item
PAD = 14                         # กันเผื่อความคลาดเคลื่อนของเบราว์เซอร์

# กระจายคำตอบให้ ก ข ค ง เท่า ๆ กัน (20 ข้อ = ช่องละ 5, 30 ข้อ = ช่องละ 7-8)
ROT4 = [0, 1, 2, 3, 1, 2, 3, 0, 2, 3, 0, 1, 3, 0, 1, 2, 0, 2, 1, 3,
        1, 3, 2, 0, 2, 0, 3, 1, 0, 1]


def prepared(rows):
    """ย้ายตัวเลือกที่ถูกไปอยู่ช่องตามตาราง ROT4 โดยลำดับตัวลวงคงเดิม"""
    out = []
    for i, (p, scene, opts, ans, why) in enumerate(rows):
        slot = ROT4[i % len(ROT4)]
        rest = opts[:ans] + opts[ans + 1:]
        new = rest[:slot] + [opts[ans]] + rest[slot:]
        out.append((p, scene, new, slot, why))
    return out


def groups_of(rows):
    """รวมข้อที่อ้างฉากเดียวกัน (scene == GLUE) ให้อยู่หน้าเดียวกัน"""
    g = []
    for i, r in enumerate(rows):
        if is_glued(r[1]) and g:
            g[-1].append(i)
        else:
            g.append([i])
    return g


def fill(need, first, rest, groups=None):
    """แบ่งข้อลงหน้าให้ใช้หน้าน้อยที่สุด แล้วเกลี่ยให้แต่ละหน้าแน่นใกล้เคียงกัน

    groups = รายการกลุ่มดัชนีข้อที่ห้ามแยกหน้ากัน (ข้อที่อ้างฉากร่วมกัน)
    หน้าแรกจุน้อยกว่าหน้าอื่นเพราะมีช่องชื่อและคำชี้แจง
    """
    if groups is None:
        groups = [[i] for i in range(len(need))]
    g = [sum(need[i] for i in grp) for grp in groups]
    n = len(g)

    def cap(page):
        return first if page == 0 else rest

    # ขั้นที่ 1 หาจำนวนหน้าน้อยที่สุดด้วยการเติมจากหน้าแรกลงไป
    pages, i = 0, 0
    while i < n:
        tot, k = 0.0, 0
        while i + k < n and tot + g[i + k] <= cap(pages):
            tot += g[i + k]
            k += 1
        assert k, (f"กลุ่มข้อที่ {groups[i][0] + 1} สูง {g[i]:.0f} "
                   f"เกินหนึ่งหน้า ({cap(pages):.0f})")
        i += k
        pages += 1

    # ขั้นที่ 2 เกลี่ยให้ที่ว่างแต่ละหน้าใกล้เคียงกัน โดยใช้หน้าเท่าเดิม
    INF = float("inf")
    dp = [[INF] * (pages + 1) for _ in range(n + 1)]
    back = [[0] * (pages + 1) for _ in range(n + 1)]
    dp[0][0] = 0.0
    for q in range(1, pages + 1):
        for i in range(1, n + 1):
            tot = 0.0
            for j in range(i, 0, -1):
                tot += g[j - 1]
                if tot > cap(q - 1):
                    break
                if dp[j - 1][q - 1] == INF:
                    continue
                slack = cap(q - 1) - tot
                c = dp[j - 1][q - 1] + slack * slack
                if c < dp[i][q]:
                    dp[i][q] = c
                    back[i][q] = j - 1
    if dp[n][pages] == INF:            # เผื่อกรณีผิดคาด ใช้แบบเติมเต็มแทน
        split, i, pno = [], 0, 0
        while i < n:
            tot, k = 0.0, 0
            while i + k < n and tot + g[i + k] <= cap(pno):
                tot += g[i + k]
                k += 1
            split.append(k)
            i += k
            pno += 1
    else:
        split, i = [], n
        for q in range(pages, 0, -1):
            j = back[i][q]
            split.append(i - j)
            i = j
        split.reverse()
    return [sum(len(grp) for grp in groups[sum(split[:k]):sum(split[:k + 1])])
            for k in range(len(split))]


def cutline():
    return '<div class="cut"><span>✂ ตัดตามเส้นประก่อนแจกนักเรียน</span></div>'


def keybox(title, detail):
    return (f'<div class="keyhead"><b>{title}</b>'
            f'<div class="wl">{detail}</div></div>')


def howbox(text):
    return f'<div class="howto"><b>คำชี้แจง</b> &nbsp;{text}</div>'


# ───────────────────────── บล็อกคำถาม ─────────────────────────

def mc_blocks(rows):
    out = []
    for i, (p, scene, opts, _a, _w) in enumerate(rows, 1):
        body = (f'<div class="item"><div class="q"><span class="n">{th(i)}</span>'
                f'<span>{p}</span></div>')
        body += scene_html(scene)
        out.append(body + opts4(opts) + "</div>")
    return out


def sa_blocks(rows):
    out = []
    for i, (p, scene, lines, _a) in enumerate(rows, 1):
        body = (f'<div class="item"><div class="q"><span class="n">{th(i)}</span>'
                f'<span>{p}</span></div>')
        body += scene_html(scene)
        out.append(body + '<div class="lines">' + "<div></div>" * lines
                   + "</div></div>")
    return out


# ───────────────────────── ประกอบเอกสาร ─────────────────────────

def build_sheet(ch, code, name, pages, key, desc):
    total = len(pages) + 1
    sub = (f"ใบงานรูปแบบ {code} · {name} · "
           f"{th(len(pages))} หน้า · เฉลยอยู่หน้าสุดท้าย")
    title = f"{ch} — ใบงาน {code} {name}"
    html = [head(title, sub, i + 1, total, who=(i == 0)) + b
            for i, b in enumerate(pages)]
    rows = "".join(
        f'<tr><td class="c">{th(pi + 1)}</td><td class="c">{th(qi + 1)}</td>'
        f'<td>{a}</td></tr>'
        for pi, pk in enumerate(key) for qi, a in enumerate(pk))
    html.append(
        head(title, sub, total, total, tag=" &mdash; เฉลยสำหรับครู")
        + cutline() + keybox("เฉลยใบงาน", f"ขอบเขต: {desc}")
        + '<table class="key"><tr><th>หน้า</th><th>ข้อ</th>'
          f'<th>คำตอบ</th></tr>{rows}</table>')
    return doc(f"ใบงาน {code}", html)


def _key_pages(title, sub, krows, head_html, npages, keychunk, tag):
    """หน้าเฉลยของครู ถ้าตารางยาวเกินหนึ่งหน้าให้แบ่งเป็นหลายหน้า"""
    chunks = [krows[i:i + keychunk] for i in range(0, len(krows), keychunk)]
    total = npages + len(chunks)
    pages = []
    for ci, rows in enumerate(chunks):
        p = head(title, sub, npages + ci + 1, total, tag=tag)
        if ci == 0:
            p += head_html
        p += f'<table class="key">{"".join(rows)}</table>'
        pages.append(p)
    return pages, total


def build_mc(ch, setname, rows, split, scope, label="ข้อสอบปรนัย",
             keychunk=22):
    blocks = mc_blocks(rows)
    krows = ['<tr><th>ข้อ</th><th>คำถาม</th><th>ตอบ</th>'
             '<th>คำอธิบาย</th></tr>']
    krows += [
        f'<tr><td class="c">{th(i)}</td><td>{p}</td>'
        f'<td class="a">{L4[a]}. {o[a]}</td><td>{w}</td></tr>'
        for i, (p, _s, o, a, w) in enumerate(rows, 1)]
    n = len(rows)
    sub = (f"ปรนัย {th(n)} ข้อ 4 ตัวเลือก (ก ข ค ง) · "
           f"ข้อละ 1 คะแนน รวม {th(n)} คะแนน")
    title = f"{ch} — {label} {setname}"
    kp, total = _key_pages(
        title, sub, krows,
        cutline() + keybox("เฉลยและคำอธิบาย", f"ขอบเขต: {scope}"),
        len(split), keychunk, " &mdash; เฉลยสำหรับครู")
    howto = howbox(
        f"ข้อสอบมี {th(n)} ข้อ ทุกข้อมีตัวเลือก ก ข ค ง "
        "<b>ให้วงกลมรอบตัวอักษรหน้าคำตอบที่ถูกที่สุดเพียงข้อเดียว</b>"
        " &nbsp;· ครูอ่านโจทย์ให้นักเรียนฟังได้")
    pages, i = [], 0
    for pno, k in enumerate(split, 1):
        pages.append(head(title, sub, pno, total, who=(pno == 1))
                     + (howto if pno == 1 else "") + "".join(blocks[i:i + k]))
        i += k
    return doc(f"ปรนัย {setname}", pages + kp)


def build_sa(ch, setname, rows, split, label="ข้อสอบอัตนัย", keychunk=14):
    blocks = sa_blocks(rows)
    krows = ['<tr><th>ข้อ</th><th>คำถาม</th><th>แนวคำตอบ</th></tr>']
    krows += [f'<tr><td class="c">{th(i)}</td><td>{p}</td><td>{a}</td></tr>'
              for i, (p, _s, _l, a) in enumerate(rows, 1)]
    n = len(rows)
    sub = (f"อัตนัย {th(n)} ข้อ · เขียนตอบลงในช่องว่าง · "
           f"ข้อละ 1 คะแนน รวม {th(n)} คะแนน")
    title = f"{ch} — {label} {setname}"
    kp, total = _key_pages(
        title, sub, krows,
        cutline() + keybox("แนวคำตอบและเกณฑ์ให้คะแนน",
                           "ข้อปลายเปิดรับคำตอบได้หลายแบบ "
                           "ให้คะแนนเมื่อเหตุผลสอดคล้องกับภาพ"
                           "หรือเงื่อนไขในโจทย์"),
        len(split), keychunk, " &mdash; แนวคำตอบสำหรับครู")
    howto = howbox(
        f"ข้อสอบมี {th(n)} ข้อ <b>ให้เขียนคำตอบลงในบรรทัดที่เว้นไว้</b> "
        "ข้อที่ให้แสดงวิธีคิด ให้เขียนหรือวาดรูปอธิบายด้วย")
    pages, i = [], 0
    for pno, k in enumerate(split, 1):
        pages.append(head(title, sub, pno, total, who=(pno == 1))
                     + (howto if pno == 1 else "") + "".join(blocks[i:i + k]))
        i += k
    return doc(f"อัตนัย {setname}", pages + kp)


# ───────────────────────── เรนเดอร์ ─────────────────────────

class Renderer:
    """ห่อ Playwright ไว้ วัดความสูงจริงแล้วค่อยแบ่งหน้าและออก PDF"""

    def __init__(self, pg, out):
        self.pg, self.out = pg, out
        self.report = []
        self.first, self.rest = self._capacity()

    def _probe(self, html, selector):
        f = self.out / "_probe.html"
        f.write_text(html, encoding="utf-8")
        self.pg.goto(f.resolve().as_uri())
        self.pg.wait_for_timeout(400)
        return self.pg.eval_on_selector_all(
            selector, "e => e.map(x => x.getBoundingClientRect().height)")

    def _capacity(self):
        """วัดหัวกระดาษ คำชี้แจง ท้ายกระดาษ เพื่อรู้ว่าแต่ละหน้าเหลือที่เท่าไร"""
        d = doc("probe", [head("บทที่ 0 ทดสอบความสูงหัวกระดาษ",
                               "คำบรรยายใต้หัวเรื่องสองบรรทัดเผื่อไว้", 1, 2,
                               who=True)
                          + howbox("ข้อความคำชี้แจงตัวอย่างที่ยาวสองบรรทัด "
                                   "เผื่อไว้ให้ความจุหน้าแรกไม่เกินจริง "
                                   "<b>เน้นข้อความบางส่วน</b> "
                                   "แล้วต่อท้ายด้วยคำอธิบายเพิ่มเติมอีกเล็กน้อย"),
                          head("บทที่ 0 ทดสอบความสูงหัวกระดาษ",
                               "คำบรรยายใต้หัวเรื่องสองบรรทัดเผื่อไว้", 2, 2)])
        d = d.replace(".page{", ".page{min-height:0;")
        hd = self._probe(d, "header")
        ho = self._probe(d, ".howto")
        ft = self._probe(d, "footer")
        first = LIMIT - hd[0] - ho[0] - ft[0] - PAD
        rest = LIMIT - hd[1] - ft[1] - PAD
        print(f"ความจุหน้าแรก {first:.0f}px · หน้าถัดไป {rest:.0f}px")
        return first, rest

    def split_for(self, blocks, groups=None):
        d = doc("probe", ["".join(blocks)]).replace(
            ".page{", ".page{min-height:0;")
        hs = self._probe(d, ".item")
        return fill([h + GAP for h in hs], self.first, self.rest, groups)

    def emit(self, fname, html, label):
        f = self.out / f"{fname}.html"
        f.write_text(html, encoding="utf-8")
        self.pg.goto(f.resolve().as_uri())
        self.pg.wait_for_timeout(600)
        hs = self.pg.eval_on_selector_all(
            ".page", "e => e.map(x => Math.round("
                     "x.getBoundingClientRect().height))")
        over = [i + 1 for i, h in enumerate(hs) if h > LIMIT + 2]
        pdf = self.out / f"{fname}.pdf"
        self.pg.pdf(path=str(pdf), format="A4", print_background=True,
                    margin={"top": "11mm", "bottom": "12mm",
                            "left": "11mm", "right": "11mm"})
        kb = pdf.stat().st_size // 1024
        print(f"{fname:<26} {len(hs)} หน้า {kb:>4} KB "
              f"{'!! ล้น ' + str(over) if over else 'ok'}  {label}")
        self.report.append({"file": fname, "pages": len(hs), "over": over,
                            "label": label})
        return over

    def _chrome(self, html):
        """วัดหัวกระดาษ คำชี้แจง ท้ายกระดาษ จากเอกสารจริงของชุดนั้น ๆ"""
        f = self.out / "_probe.html"
        f.write_text(html, encoding="utf-8")
        self.pg.goto(f.resolve().as_uri())
        self.pg.wait_for_timeout(400)
        hd = self.pg.eval_on_selector_all(
            "header", "e => e.map(x => x.getBoundingClientRect().height)")
        ho = self.pg.eval_on_selector_all(
            ".howto", "e => e.map(x => x.getBoundingClientRect().height)")
        ft = self.pg.eval_on_selector_all(
            "footer", "e => e.map(x => x.getBoundingClientRect().height)")
        # เผื่อระยะขอบของหัวกระดาษกับคำชี้แจงที่ไม่รวมในความสูงของกล่อง
        first = LIMIT - hd[0] - (ho[0] + 12 if ho else 0) - ft[0] - 17
        rest = LIMIT - hd[-1] - ft[-1] - 17
        return first, rest

    def emit_fit(self, fname, make, blocks, groups, label):
        """แบ่งหน้าโจทย์และหน้าเฉลย ถ้าหน้าใดล้นให้ลดแล้วลองใหม่จนพอดี"""
        d = doc("probe", ["".join(blocks)]).replace(
            ".page{", ".page{min-height:0;")
        need = [h + GAP for h in self._probe(d, ".item")]
        kc = 22
        first, rest = self._chrome(make([len(need)], kc))
        for _ in range(10):
            split = fill(need, first, rest, groups)
            over = self.emit(fname, make(split, kc), label)
            if not over:
                return split
            self.report.pop()
            if any(o > len(split) for o in over):      # หน้าเฉลยล้น
                kc -= 3
            if any(o <= len(split) for o in over):     # หน้าโจทย์ล้น
                first -= 26
                rest -= 26
        raise RuntimeError(f"{fname} แบ่งหน้าไม่ลงตัว")


def run(here, ch, prefix, scope, sheets_mod, exams_mod,
        mclabel="ข้อสอบปรนัย"):
    """สร้างไฟล์ทั้งหมดของหนึ่งบท แล้วเขียน _report.json"""
    from playwright.sync_api import sync_playwright

    out = pathlib.Path(here) / "out"
    out.mkdir(exist_ok=True)
    with sync_playwright() as pw:
        br = pw.chromium.launch()
        pg = br.new_page(viewport={"width": 794, "height": 1123})
        pg.emulate_media(media="print")
        r = Renderer(pg, out)

        for code, name, fn, key, desc in sheets_mod.FORMS:
            r.emit(f"{prefix}_Sheet_{code}",
                   build_sheet(ch, code, name, fn(), key, desc),
                   f"ใบงานรูปแบบ {code} {name}")

        for idx, (setname, rows) in enumerate(exams_mod.SETS_MC, 1):
            rows = prepared(rows)
            r.emit_fit(
                f"{prefix}_MC_{idx}",
                lambda sp, kc, rw=rows, sn=setname:
                    build_mc(ch, sn, rw, sp, scope, mclabel, kc),
                mc_blocks(rows), groups_of(rows),
                f"ปรนัย {len(rows)} ข้อ {setname}")

        for idx, (setname, rows) in enumerate(exams_mod.SETS_SA, 1):
            r.emit_fit(
                f"{prefix}_SA_{idx}",
                lambda sp, kc, rw=rows, sn=setname:
                    build_sa(ch, sn, rw, sp, keychunk=kc),
                sa_blocks(rows), groups_of(rows),
                f"อัตนัย {len(rows)} ข้อ {setname}")

        br.close()

    (out / "_report.json").write_text(
        json.dumps(r.report, ensure_ascii=False, indent=1), encoding="utf-8")
    print("\nรวม", len(r.report), "ไฟล์")
    return r.report
