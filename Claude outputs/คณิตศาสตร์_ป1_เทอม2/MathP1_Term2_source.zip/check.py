# -*- coding: utf-8 -*-
"""ตรวจงานกลาง ใช้ร่วมกันทุกบท — เน้นจุดที่เคยพลาดมาแล้วในชุดก่อน ๆ"""
import json
import pathlib
import re
from collections import Counter

from engine import prepared

STATE = {"bad": 0}


def fail(m):
    STATE["bad"] += 1
    print("  ✗", m)


def _cross(sets, tag):
    """โจทย์ห้ามซ้ำข้ามชุด คืนค่าจำนวนที่ซ้ำ"""
    seen, n = {}, 0
    for name, rows in sets:
        for p in sorted({r[0] for r in rows}):
            if p in seen:
                n += 1
                fail(f"โจทย์{tag}ซ้ำระหว่าง {seen[p]} กับ {name}: {p[:40]}")
            seen[p] = name
    return n


def check_mc(sets, n_items, tag="ปรนัย"):
    print(f"== ข้อสอบ{tag} ==")
    for name, rows in sets:
        if len(rows) != n_items:
            fail(f"{name} มี {len(rows)} ข้อ ไม่ใช่ {n_items}")
        done = prepared(rows)
        dist = Counter()
        for i, ((_p0, _s0, o0, a0, _w0), (p, _s, o, a, w)) in enumerate(
                zip(rows, done), 1):
            dist[a] += 1
            if len(o) != 4:
                fail(f"{name} ข้อ {i} มี {len(o)} ตัวเลือก ต้องมี 4")
            if o[a] != o0[a0]:
                fail(f"{name} ข้อ {i} หมุนตัวเลือกแล้วเฉลยเพี้ยน")
            if set(o) != set(o0):
                fail(f"{name} ข้อ {i} หมุนแล้วตัวเลือกหาย/เกิน")
            if len(set(o)) != len(o):
                fail(f"{name} ข้อ {i} ตัวเลือกซ้ำกัน")
            if not w.strip():
                fail(f"{name} ข้อ {i} ไม่มีคำอธิบายเฉลย")
            if not p.strip():
                fail(f"{name} ข้อ {i} ไม่มีโจทย์")
        spread = [dist.get(j, 0) for j in range(4)]
        if max(spread) - min(spread) > 1:
            fail(f"{name} เฉลยกระจายไม่สม่ำเสมอ {spread}")
        prompts = [r[0] for r in rows]
        for p in sorted(set(prompts)):
            if prompts.count(p) > 1:
                fail(f"{name} มีโจทย์ซ้ำกันภายในชุด: {p[:46]}")
        print(f"  ✓ {name} {len(rows)} ข้อ · เฉลยกระจาย ก{spread[0]} "
              f"ข{spread[1]} ค{spread[2]} ง{spread[3]}")
    if not _cross(sets, tag):
        print(f"  ✓ {tag}ทุกชุดไม่มีโจทย์ซ้ำข้ามชุด")


def check_sa(sets, n_items):
    print("== ข้อสอบอัตนัย ==")
    for name, rows in sets:
        if len(rows) != n_items:
            fail(f"อัตนัย {name} มี {len(rows)} ข้อ ไม่ใช่ {n_items}")
        for i, (p, _s, lines, a) in enumerate(rows, 1):
            if not p.strip():
                fail(f"อัตนัย {name} ข้อ {i} ไม่มีโจทย์")
            if not str(a).strip():
                fail(f"อัตนัย {name} ข้อ {i} ไม่มีแนวคำตอบ")
            if not 1 <= lines <= 6:
                fail(f"อัตนัย {name} ข้อ {i} เว้น {lines} บรรทัด ผิดปกติ")
        print(f"  ✓ อัตนัย {name} {len(rows)} ข้อ มีแนวคำตอบครบ")
    if not _cross(sets, "อัตนัย"):
        print("  ✓ อัตนัยทุกชุดไม่มีโจทย์ซ้ำข้ามชุด")


def check_sheets(forms):
    print("== ใบงาน ==")
    allq = {}
    for code, name, fn, key, _d in forms:
        pages = fn()
        if len(pages) != 4:
            fail(f"ใบงาน {code} มี {len(pages)} หน้า ไม่ใช่ 4")
        if len(key) != len(pages):
            fail(f"ใบงาน {code} เฉลย {len(key)} หน้า โจทย์ {len(pages)} หน้า")
        for pi, (html, pk) in enumerate(zip(pages, key), 1):
            n_items = len(re.findall(r'class="item"', html))
            if n_items != len(pk):
                fail(f"ใบงาน {code} หน้า {pi} มี {n_items} ข้อ "
                     f"แต่เฉลยมี {len(pk)} ข้อ")
            for qi, a in enumerate(pk, 1):
                if not str(a).strip():
                    fail(f"ใบงาน {code} หน้า {pi} ข้อ {qi} เฉลยว่าง")
            if 'class="howto"' not in html:
                fail(f"ใบงาน {code} หน้า {pi} ไม่มีคำชี้แจง")
            for q in re.findall(r'<div class="q">.*?</div>', html):
                t = re.sub(r"<[^>]+>", "", q).strip()
                if len(t) > 12:
                    allq.setdefault(t, []).append(f"{code} หน้า {pi}")
    dup = {k: v for k, v in allq.items() if len(v) > 1}
    if dup:
        k = next(iter(dup))
        fail(f"ใบงานมีโจทย์ซ้ำ {len(dup)} ข้อ เช่น {k[:40]} ที่ {dup[k]}")
    else:
        print("  ✓ ใบงานทุกรูปแบบไม่มีโจทย์ซ้ำกันเลย")
    for code, name, _fn, _k, _d in forms:
        print(f"  ✓ ใบงาน {code} {name} 4 หน้า เฉลยครบทุกข้อ")


def check_pdfs(out):
    print("== ไฟล์ PDF ==")
    out = pathlib.Path(out)
    rep = json.loads((out / "_report.json").read_text(encoding="utf-8"))
    for r in rep:
        f = out / f"{r['file']}.pdf"
        if not f.exists():
            fail(f"ไม่มีไฟล์ {r['file']}.pdf")
        elif r["over"]:
            fail(f"{r['file']} หน้าล้น {r['over']}")
        else:
            print(f"  ✓ {r['file']}.pdf {r['pages']} หน้า "
                  f"{f.stat().st_size // 1024} KB")
    return rep


def check_print_spec(out, sample):
    print("== ลายน้ำและข้อกำหนดการพิมพ์ ==")
    html = (pathlib.Path(out) / f"{sample}.html").read_text(encoding="utf-8")
    for label, needle in [("ลายน้ำ 11pt", "font-size:11pt"),
                          ("ลายน้ำทึบ 4.5%", "opacity:.045"),
                          ("ลายน้ำแถบบน-ล่างเท่านั้น", "top:11%"),
                          ("ตัวเลือกกระจายเต็มความกว้าง", "flex:1"),
                          ("เส้นประให้ตัดหน้าเฉลย", "ตัดตามเส้นประ")]:
        if needle in html:
            print(f"  ✓ {label}")
        else:
            fail(f"ไม่พบ {label}")
    if re.search(r"background:#(0|1|2|3)[0-9a-f]{5}", html):
        fail("พบพื้นสีทึบเข้ม ซึ่งครูสั่งห้ามไว้")
    else:
        print("  ✓ ไม่มีพื้นสีทึบเข้ม")


def done():
    print("\nไม่ผ่าน" if STATE["bad"] else "\nผ่านทั้งหมด")
    return STATE["bad"]
