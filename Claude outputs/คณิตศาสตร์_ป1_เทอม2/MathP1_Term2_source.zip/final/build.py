# -*- coding: utf-8 -*-
"""สร้างข้อสอบรวบยอดเทอม 2 — ปรนัยพื้นฐาน 2 ชุด ท้าทาย 2 ชุด อัตนัย 2 ชุด"""
import json
import pathlib
import sys

HERE = pathlib.Path(__file__).parent
sys.path.insert(0, str(HERE.parent))
sys.path.insert(0, str(HERE))

import engine                                         # noqa: E402
import exams                                          # noqa: E402
from playwright.sync_api import sync_playwright       # noqa: E402

CH = "ข้อสอบรวบยอด คณิตศาสตร์ ป.1 เทอม 2"
SCOPE = ("บทที่ 8 ตำแหน่งและอันดับที่ · บทที่ 9 รูปเรขาคณิต · "
         "บทที่ 10 จำนวนนับ 21–100 · บทที่ 11 การวัดความยาว · "
         "บทที่ 12 การบวก · บทที่ 13 การลบ · บทที่ 14 โจทย์ปัญหา")

if __name__ == "__main__":
    out = HERE / "out"
    out.mkdir(exist_ok=True)
    with sync_playwright() as pw:
        br = pw.chromium.launch()
        pg = br.new_page(viewport={"width": 794, "height": 1123})
        pg.emulate_media(media="print")
        r = engine.Renderer(pg, out)

        jobs = [("Basic", exams.SETS_BASIC, "ปรนัยรวบยอด ระดับพื้นฐาน"),
                ("Challenge", exams.SETS_CHAL,
                 "ปรนัยรวบยอด ระดับแข่งขันท้าทาย")]
        for tag, sets, label in jobs:
            for idx, (setname, rows) in enumerate(sets, 1):
                rw = engine.prepared(rows)
                r.emit_fit(
                    f"MathP1_Final_{tag}_{idx}",
                    lambda sp, kc, w=rw, s=setname, lb=label:
                        engine.build_mc(CH, s, w, sp, SCOPE, lb, kc),
                    engine.mc_blocks(rw), engine.groups_of(rw),
                    f"{label} 30 ข้อ {setname}")

        for idx, (setname, rows) in enumerate(exams.SETS_SA, 1):
            r.emit_fit(
                f"MathP1_Final_SA_{idx}",
                lambda sp, kc, w=rows, s=setname:
                    engine.build_sa(CH, s, w, sp, "อัตนัยรวบยอด", kc),
                engine.sa_blocks(rows), engine.groups_of(rows),
                f"อัตนัยรวบยอด 10 ข้อ {setname}")
        br.close()

    (out / "_report.json").write_text(
        json.dumps(r.report, ensure_ascii=False, indent=1), encoding="utf-8")
    print("\nรวม", len(r.report), "ไฟล์")
