# -*- coding: utf-8 -*-
"""ตรวจข้อสอบรวบยอดเทอม 2 ก่อนส่งครู"""
import pathlib
import sys

HERE = pathlib.Path(__file__).parent
sys.path.insert(0, str(HERE.parent))
sys.path.insert(0, str(HERE))

import check                                          # noqa: E402
import exams                                          # noqa: E402

check.check_mc(exams.SETS_BASIC, 30, "ปรนัยพื้นฐาน")
check.check_mc(exams.SETS_CHAL, 30, "ปรนัยท้าทาย")
check.check_sa(exams.SETS_SA, 10)
check.check_pdfs(HERE / "out")
check.check_print_spec(HERE / "out", "MathP1_Final_Basic_1")
sys.exit(1 if check.done() else 0)
