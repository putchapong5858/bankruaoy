# -*- coding: utf-8 -*-
"""รวมไฟล์ทั้งหมดเป็นรูปเล่ม — เล่มรวมทั้งเทอม และเล่มย่อยรายบท"""
import json
import pathlib
import shutil

import pypdf

HERE = pathlib.Path(__file__).parent
BOOK = HERE / "book"
DIRS = ["ch08", "ch09", "ch10", "ch11", "ch12", "ch13", "ch14", "final"]
NAME = {"ch08": "บทที่08_การบอกตำแหน่งและอันดับที่",
        "ch09": "บทที่09_รูปเรขาคณิต",
        "ch10": "บทที่10_จำนวนนับ21ถึง100",
        "ch11": "บทที่11_การวัดความยาว",
        "ch12": "บทที่12_การบวกผลบวกไม่เกิน100",
        "ch13": "บทที่13_การลบตัวตั้งไม่เกิน100",
        "ch14": "บทที่14_โจทย์ปัญหาบวกลบ",
        "final": "ข้อสอบรวบยอดเทอม2"}

BOOK.mkdir(exist_ok=True)
for d in DIRS:
    (BOOK / NAME[d]).mkdir(exist_ok=True)

whole = pypdf.PdfWriter()
front = HERE / "front" / "out" / "MathP1_Front.pdf"
whole.append(str(front))
shutil.copy(front, BOOK / "MathP1_00_ส่วนหน้ารูปเล่ม.pdf")

summary = []
for d in DIRS:
    rep = json.loads((HERE / d / "out" / "_report.json")
                     .read_text(encoding="utf-8"))
    part = pypdf.PdfWriter()
    for r in rep:
        src = HERE / d / "out" / f"{r['file']}.pdf"
        part.append(str(src))
        whole.append(str(src))
        shutil.copy(src, BOOK / NAME[d] / f"{r['file']}.pdf")
    out = BOOK / f"MathP1_{NAME[d]}_รวมทั้งบท.pdf"
    part.write(str(out))
    part.close()
    summary.append((NAME[d], len(rep), sum(r["pages"] for r in rep),
                    out.stat().st_size // 1024))

bookpdf = BOOK / "MathP1_Term2_รวมทั้งเล่ม.pdf"
whole.write(str(bookpdf))
whole.close()

for n, f, p, kb in summary:
    print(f"{n:<36} {f} ไฟล์ {p:>3} หน้า  เล่มย่อย {kb:>5} KB")
r = pypdf.PdfReader(str(bookpdf))
print(f"\nเล่มรวมทั้งเทอม {len(r.pages)} หน้า "
      f"{bookpdf.stat().st_size // 1024 // 1024} MB")
