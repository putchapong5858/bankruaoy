# -*- coding: utf-8 -*-
"""สร้าง PDF ทั้งหมดของบทที่ 12 การบวกที่ผลบวกไม่เกิน 100"""
import pathlib
import sys

HERE = pathlib.Path(__file__).parent
sys.path.insert(0, str(HERE.parent))
sys.path.insert(0, str(HERE))

import engine                                         # noqa: E402
import exams                                          # noqa: E402
import sheets                                         # noqa: E402

CH = "บทที่ 12 การบวกที่ผลบวกไม่เกิน 100"
SCOPE = ("หาผลบวกจำนวนสองหลักกับจำนวนหนึ่งหลัก · หาผลบวกจำนวนสองหลักกับจำนวนสองหลัก ที่ผลบวกไม่เกิน 100")

if __name__ == "__main__":
    engine.run(HERE, CH, "MathP1_C12", SCOPE, sheets, exams)
