# -*- coding: utf-8 -*-
"""สร้าง PDF ทั้งหมดของบทที่ 9"""
import pathlib
import sys

HERE = pathlib.Path(__file__).parent
sys.path.insert(0, str(HERE.parent))
sys.path.insert(0, str(HERE))

import engine                                         # noqa: E402
import exams                                          # noqa: E402
import sheets                                         # noqa: E402

CH = "บทที่ 9 รูปเรขาคณิต"
SCOPE = ("จำแนกทรงสี่เหลี่ยมมุมฉาก ทรงกลม ทรงกระบอก กรวย · "
         "จำแนกและบอกลักษณะรูปสามเหลี่ยม รูปสี่เหลี่ยม วงกลม วงรี · "
         "แบบรูปซ้ำของรูปเรขาคณิต")

if __name__ == "__main__":
    engine.run(HERE, CH, "MathP1_C09", SCOPE, sheets, exams)
