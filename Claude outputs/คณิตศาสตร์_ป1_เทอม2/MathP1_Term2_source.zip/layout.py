# -*- coding: utf-8 -*-
"""โครงหน้ากระดาษกลาง ใช้ร่วมกันทุกบทของคณิตศาสตร์ ป.1 เทอม 2

ข้อกำหนดการพิมพ์ที่ครูสั่งไว้ (ใช้กับทุกไฟล์)
  · ห้ามพื้นสีทึบเข้ม ใช้พื้นอ่อนคู่ตัวอักษรเข้มคมชัด ประหยัดหมึก
  · ตัวเลือกคำตอบห้ามวางชิดกัน ให้กระจายเต็มความกว้างของข้อ
  · ลายน้ำเหลือเฉพาะแถบบนกับแถบล่าง ขนาด 11pt ทึบ 4.5%
  · เฉลยแยกไว้หน้าครูท้ายชุด มีเส้นประให้ตัดออกก่อนแจกเด็ก
"""
import pathlib

HERE = pathlib.Path(__file__).resolve().parent
FONTS = (HERE.parent / "thaiword40" / "fonts.css").read_text(encoding="utf-8")

TH = "๐๑๒๓๔๕๖๗๘๙"
L4 = "กขคง"


def th(n):
    """เลขไทย ใช้กับเลขข้อและเลขหน้า"""
    return "".join(TH[int(c)] for c in str(n))


# ลายน้ำ แถบบน + แถบล่าง อย่างละ 3 ตำแหน่ง
WM = "".join(
    f'<span style="left:{4 + col * 33}%;top:{top}%">เรียนพิเศษบ้านครูอ้อย</span>'
    for top in (11, 92) for col in range(3))

CSS = r"""
@page{size:A4;margin:11mm 11mm 12mm}
*{margin:0;padding:0;box-sizing:border-box}
body{font-family:Sarabun,sans-serif;color:#13303f;line-height:1.5;background:#fff;
     -webkit-print-color-adjust:exact;print-color-adjust:exact}
.page{position:relative;min-height:250mm;display:flex;flex-direction:column}
.page:not(:last-child){break-after:page;page-break-after:always}
.mark{position:fixed;inset:0;z-index:5;pointer-events:none;overflow:hidden}
.mark span{position:absolute;font-size:11pt;font-weight:700;color:#0A5680;
  opacity:.045;transform:rotate(-32deg);white-space:nowrap;letter-spacing:.06em}
main{position:relative;z-index:1;flex:1;display:flex;flex-direction:column}
/* ข้อคำถามยืดเต็มหน้า เด็ก ป.1 จะได้มีที่เขียนกว้าง ๆ ไม่เหลือหน้าว่าง */
main>.item{flex:1 1 auto}
/* หน้าที่มีข้อน้อย ให้กล่องยืดแต่พอดี ที่เหลือปล่อยว่างไว้ ไม่ยืดจนเทอะทะ */
main.loose>.item{flex:1 1 auto}
main.loose::after{content:"";display:block;flex:2 1 auto}

/* ---------- หัวกระดาษ ---------- */
header{border-bottom:2.5px solid #0A5680;padding-bottom:4px;margin-bottom:9px}
.brand{display:flex;justify-content:space-between;align-items:flex-end}
.brand b{font-size:14pt;color:#0A5680}
.brand span{font-size:9.5pt;color:#5b7585}
h1{font-size:14pt;margin-top:2px;line-height:1.4}
.sub{font-size:10pt;color:#44677a;margin-top:1px}
.who{display:flex;gap:14px;font-size:10.5pt;margin-top:6px;color:#2b4b5c}
.who i{font-style:normal;flex:1;border-bottom:1px dotted #9db4c0;padding-bottom:2px}
.who i.sc{flex:0 0 104px}

/* ---------- คำชี้แจง ---------- */
.howto{background:#e8f3fa;border-left:5px solid #0A5680;border-radius:7px;
       padding:6px 12px;margin:2px 0 10px;font-size:11.5pt;line-height:1.45}
.howto b{color:#0A5680}

/* ---------- ข้อคำถาม ---------- */
.item{border:1.4px solid #cfe0ea;border-radius:10px;padding:11px 14px 12px;
      margin-bottom:9px;background:#fbfdff;break-inside:avoid;
      display:flex;flex-direction:column;justify-content:center}
.q{display:flex;gap:9px;align-items:baseline;font-size:14pt;font-weight:600;
   line-height:1.45}
.n{flex:0 0 auto;min-width:27px;height:25px;border-radius:13px;background:#0A5680;
   color:#fff;font-size:10.5pt;font-weight:700;display:inline-flex;
   align-items:center;justify-content:center;line-height:1;padding:0 6px}
.q em{font-style:normal;color:#b4471f;font-weight:700}

/* ตัวเลือก ก ข ค ง กระจายเต็มความกว้าง ไม่วางชิดกัน */
.opts{display:flex;gap:12px;margin-top:6px}
.opt{flex:1;border:1.3px solid #d8e6ee;border-radius:9px;background:#fff;
     padding:9px 7px;text-align:center;font-size:12.5pt}
.kc{display:inline-flex;width:21px;height:21px;border:1.6px solid #0A5680;
    border-radius:50%;align-items:center;justify-content:center;
    font-size:10pt;font-weight:700;color:#0A5680;line-height:1;margin-right:5px}
.opts.col{flex-direction:column;gap:4px}
.opts.col .opt{text-align:left;padding:4px 10px}

/* ช่องให้เด็กเขียนคำตอบ */
.ans{display:inline-block;min-width:96px;border-bottom:1.6px solid #7aa0b5;
     margin:0 4px}
.ansbox{display:inline-block;width:40px;height:34px;border:1.6px solid #7aa0b5;
        border-radius:6px;vertical-align:middle;margin:0 4px;background:#fff}
.lines{margin-top:6px}
.lines div{border-bottom:1px dotted #9db4c0;height:32px}

/* ---------- ฉาก/ภาพประกอบ ---------- */
.scene{text-align:center;margin:7px 0 3px}
.row{display:flex;justify-content:center;align-items:flex-end;gap:14px}
.fig{text-align:center;font-size:10.5pt;color:#44677a;line-height:1.3}
.fig .e{font-size:40pt;line-height:1.15;display:block}
.fig b{display:block;font-size:11pt;color:#13303f;font-weight:600}
.shelf{display:inline-block;border:1.6px solid #b9d2e0;border-radius:9px;
       background:#f4fafd;padding:7px 11px}
.shelf .lv{display:flex;gap:16px;justify-content:center;align-items:center;
           padding:4px 0;border-bottom:1.4px dashed #c9dde8}
.shelf .lv:last-child{border-bottom:none}
.tag{display:inline-block;background:#e8f3fa;border:1.2px solid #a9cde0;
     border-radius:999px;padding:1px 9px;font-size:9.5pt;color:#0A5680;
     font-weight:600}

/* ---------- ตาราง/ตารางรหัส ---------- */
table.grid{border-collapse:collapse;margin:6px auto}
table.grid td,table.grid th{border:1.3px solid #b9d2e0;padding:5px 9px;
  text-align:center;font-size:11pt}
table.grid th{background:#eef6fb;color:#0A5680;font-weight:700}

/* ---------- ท้ายกระดาษ ---------- */
footer{font-size:8.5pt;color:#7b93a1;text-align:center;margin-top:8px;
       border-top:1px dotted #c4d6e0;padding-top:4px;line-height:1.5}

/* ---------- หน้าเฉลยสำหรับครู ---------- */
.cut{border-top:2px dashed #b4471f;margin:0 0 9px;position:relative;height:0}
.cut span{position:absolute;top:-10px;left:50%;transform:translateX(-50%);
  background:#fff;padding:0 9px;font-size:9pt;color:#b4471f;font-weight:600}
.keyhead{background:#e8f3fa;border:1.4px solid #0A5680;border-radius:9px;
         padding:7px 11px;margin-bottom:9px}
.keyhead b{color:#0A5680;font-size:12.5pt}
.keyhead .wl{font-size:10pt;color:#2b4b5c;margin-top:4px;line-height:1.55}
table.key{width:100%;border-collapse:collapse;font-size:9pt;line-height:1.35}
table.key th,table.key td{border:1px solid #c9dde8;padding:2px 6px;
  vertical-align:top}
table.key th{background:#eef6fb;color:#0A5680;font-weight:700}
table.key td.c{text-align:center;font-weight:700;color:#0A5680;width:30px}
table.key td.a{text-align:center;font-weight:700;color:#0A5680;width:70px}
"""

from draw import CSS_EXTRA                            # noqa: E402,E402
CSS += CSS_EXTRA

FOOT = ("เรียนพิเศษบ้านครูอ้อย · หนองบัวลำภู · bankruaoy.com · "
        "สร้างขึ้นใหม่ทั้งหมด ไม่ได้คัดลอกจากแบบเรียนใด")


def head(title, sub, page, pages, who=False, tag=""):
    name = ('<div class="who"><i>ชื่อ–นามสกุล</i><i>ชั้น</i>'
            '<i class="sc">เลขที่</i></div>') if who else ""
    return (f'<header><div class="brand"><b>เรียนพิเศษบ้านครูอ้อย</b>'
            f'<span>หน้า {page}/{pages}</span></div>'
            f'<h1>{title}{tag}</h1><div class="sub">{sub}</div>{name}</header>')


def doc(title, pages_html):
    """ประกอบหน้าทั้งหมดเป็นเอกสาร HTML เดียว

    หน้าที่มีข้อน้อยกว่า 4 ข้อจะใส่คลาส loose ไม่ให้กล่องข้อยืดจนดูโหรงเหรง
    ส่วนหน้าที่มีข้อมากพอ กล่องจะยืดเต็มหน้าให้เด็กมีที่เขียนกว้าง ๆ
    """
    parts = []
    for p in pages_html:
        cls = "" if p.count('class="item"') >= 3 else ' class="loose"'
        parts.append(f'<section class="page"><div class="mark">{WM}</div>'
                     f'<main{cls}>{p}</main>'
                     f'<footer>{FOOT}</footer></section>')
    body = "".join(parts)
    return ("<!doctype html><html lang='th'><head><meta charset='utf-8'>"
            f"<title>{title}</title><style>{FONTS}\n{CSS}</style></head>"
            f"<body>{body}</body></html>")


# ---------- ตัวช่วยวาดฉาก ----------

def row(items, caption=""):
    """แถวของสิ่งของ/คน  items = [(อีโมจิ, ชื่อใต้ภาพ), ...]"""
    figs = "".join(
        f'<div class="fig"><span class="e">{e}</span>'
        f'{f"<b>{n}</b>" if n else ""}</div>' for e, n in items)
    cap = f'<div class="tag">{caption}</div>' if caption else ""
    return f'<div class="scene"><div class="row">{figs}</div>{cap}</div>'


def shelf(levels, caption=""):
    """ชั้นวางของ levels = [[(อีโมจิ, ชื่อ), ...], ...] เรียงจากชั้นบนลงล่าง"""
    lv = "".join(
        '<div class="lv">' + "".join(
            f'<div class="fig"><span class="e">{e}</span>'
            f'{f"<b>{n}</b>" if n else ""}</div>' for e, n in row_)
        + "</div>" for row_ in levels)
    cap = f'<div class="tag">{caption}</div>' if caption else ""
    return f'<div class="scene"><div class="shelf">{lv}</div>{cap}</div>'


def opts4(choices, inline=True):
    """ตัวเลือก ก ข ค ง — สั้นวางแนวนอน ยาววางแนวตั้ง"""
    plain = [c for c in choices if "<" not in c]
    long_ = max((len(c) for c in plain), default=0)
    cls = "opts" if inline and long_ <= 14 else "opts col"
    cells = "".join(f'<div class="opt"><span class="kc">{L4[i]}</span>{c}</div>'
                    for i, c in enumerate(choices))
    return f'<div class="{cls}">{cells}</div>'


def item(no, prompt, extra=""):
    return (f'<div class="item"><div class="q"><span class="n">{th(no)}</span>'
            f'<span>{prompt}</span></div>{extra}</div>')


def how(text):
    """แถบคำชี้แจงหัวใบงาน"""
    return f'<div class="howto"><b>คำชี้แจง</b> &nbsp;{text}</div>'


def blank(n=1):
    """เส้นให้เด็กเขียนคำตอบ"""
    return '<span class="ans">&nbsp;</span>' * n


def wide(px=260):
    """เส้นยาวให้เด็กเขียนคำตอบ กำหนดความกว้างได้"""
    return f'<span class="ans" style="min-width:{px}px">&nbsp;</span>'


def box(n=1):
    """กล่องสี่เหลี่ยมให้เด็กเติมตัวเลข"""
    return '<span class="ansbox"></span>' * n


def lines(n):
    """บรรทัดประให้เขียนคำตอบยาว"""
    return '<div class="lines">' + "<div></div>" * n + "</div>"


def items(qs, start=1):
    """สร้างหลายข้อรวดเดียว qs = [โจทย์, ...] หรือ [(โจทย์, ส่วนเสริม), ...]"""
    out = []
    for i, q in enumerate(qs, start):
        if isinstance(q, tuple):
            out.append(item(i, q[0], q[1]))
        else:
            out.append(item(i, q))
    return "".join(out)
