# -*- coding: utf-8 -*-
"""สร้าง PDF ทั้งหมดของบทที่ 13 การลบจำนวนที่ตัวตั้งไม่เกิน 100"""
import pathlib
import sys

HERE = pathlib.Path(__file__).parent
sys.path.insert(0, str(HERE.parent))
sys.path.insert(0, str(HERE))

import engine                                         # noqa: E402
import exams                                          # noqa: E402
import sheets                                         # noqa: E402

CH = "บทที่ 13 การลบจำนวนที่ตัวตั้งไม่เกิน 100"
SCOPE = ("หาผลลบจำนวนสองหลักกับจำนวนหนึ่งหลัก · หาผลลบจำนวนสองหลักกับจำนวนสองหลัก ตัวตั้งมากกว่า 20 แต่ไม่เกิน 100 · หาตัวไม่ทราบค่าในประโยคสัญลักษณ์การบวกและการลบ")

if __name__ == "__main__":
    engine.run(HERE, CH, "MathP1_C13", SCOPE, sheets, exams)
