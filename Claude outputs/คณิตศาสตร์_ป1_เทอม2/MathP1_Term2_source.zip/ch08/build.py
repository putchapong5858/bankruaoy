# -*- coding: utf-8 -*-
"""สร้าง PDF ทั้งหมดของบทที่ 8 — ใบงาน 4 ไฟล์ + ข้อสอบ 4 ไฟล์"""
import pathlib
import sys

HERE = pathlib.Path(__file__).parent
sys.path.insert(0, str(HERE.parent))
sys.path.insert(0, str(HERE))

import engine                                         # noqa: E402
import exams                                          # noqa: E402
import sheets                                         # noqa: E402

CH = "บทที่ 8 การบอกตำแหน่งและอันดับที่"
SCOPE = ("ตำแหน่ง ซ้าย ขวา หน้า หลัง ระหว่าง บน ล่าง · "
         "อันดับที่เมื่อนับจากทิศที่กำหนด · ความสัมพันธ์ของอันดับจากสองทิศ")

if __name__ == "__main__":
    engine.run(HERE, CH, "MathP1_C08", SCOPE, sheets, exams)
