# -*- coding: utf-8 -*-
"""ภาพประกอบวาดเองด้วย SVG ใช้ร่วมกันทุกบท

ทุกรูปวาดขึ้นใหม่ทั้งหมด เป็นรูปทรงเรขาคณิตพื้นฐานและอุปกรณ์การเรียนทั่วไป
ใช้เส้นเข้มบนพื้นอ่อนตามที่ครูสั่ง ไม่มีพื้นสีทึบ ประหยัดหมึกเวลาปริ้น
"""

INK = "#13303f"        # สีเส้น
SOFT = "#eaf4fb"       # พื้นอ่อน
SOFT2 = "#fdf2e6"      # พื้นอ่อนโทนอุ่น
EDGE = "#0A5680"       # เส้นเน้น


def _svg(w, h, body, cls="pic"):
    return (f'<svg class="{cls}" viewBox="0 0 {w} {h}" width="{w}" '
            f'height="{h}" xmlns="http://www.w3.org/2000/svg">{body}</svg>')


# ───────────────────── รูปเรขาคณิตสามมิติ ─────────────────────

def solid(kind, s=74):
    """ทรงสี่เหลี่ยมมุมฉาก ทรงกลม ทรงกระบอก กรวย ทรงสามเหลี่ยม(พีระมิด)"""
    st = f'fill="{SOFT}" stroke="{INK}" stroke-width="2.2"'
    dash = f'fill="none" stroke="{INK}" stroke-width="1.6" stroke-dasharray="4 3"'
    if kind == "กล่อง":            # ทรงสี่เหลี่ยมมุมฉาก
        b = (f'<path d="M14 30 H62 V78 H14 Z" {st}/>'
             f'<path d="M14 30 L32 14 H80 L62 30" {st}/>'
             f'<path d="M62 30 L80 14 V62 L62 78" {st}/>')
        return _svg(94, 92, b)
    if kind == "ลูกบาศก์":
        b = (f'<path d="M16 32 H58 V74 H16 Z" {st}/>'
             f'<path d="M16 32 L34 16 H76 L58 32" {st}/>'
             f'<path d="M58 32 L76 16 V58 L58 74" {st}/>')
        return _svg(92, 88, b)
    if kind == "ทรงกลม":
        b = (f'<circle cx="46" cy="46" r="34" {st}/>'
             f'<ellipse cx="46" cy="46" rx="34" ry="12" {dash}/>')
        return _svg(92, 92, b)
    if kind == "ทรงกระบอก":
        b = (f'<path d="M18 24 V68 A28 12 0 0 0 74 68 V24 Z" {st}/>'
             f'<ellipse cx="46" cy="24" rx="28" ry="12" {st}/>')
        return _svg(92, 92, b)
    if kind == "กรวย":
        b = (f'<path d="M46 10 L76 72 A30 12 0 0 1 16 72 Z" {st}/>'
             f'<path d="M16 72 A30 12 0 0 0 76 72" {dash}/>')
        return _svg(92, 92, b)
    if kind == "พีระมิด":
        b = (f'<path d="M46 12 L80 70 H12 Z" {st}/>'
             f'<path d="M46 12 L58 78 L12 70" {dash}/>'
             f'<path d="M58 78 L80 70" {dash}/>')
        return _svg(92, 92, b)
    raise ValueError(kind)


# ───────────────────── รูปเรขาคณิตสองมิติ ─────────────────────

def plane(kind, s=72):
    st = f'fill="{SOFT}" stroke="{EDGE}" stroke-width="2.2"'
    if kind == "วงกลม":
        return _svg(84, 84, f'<circle cx="42" cy="42" r="33" {st}/>')
    if kind == "วงรี":
        return _svg(96, 76, f'<ellipse cx="48" cy="38" rx="42" ry="24" {st}/>')
    if kind == "สามเหลี่ยม":
        return _svg(88, 80, f'<path d="M44 8 L82 72 H6 Z" {st}/>')
    if kind == "สามเหลี่ยมมุมฉาก":
        return _svg(88, 80, f'<path d="M10 8 V72 H82 Z" {st}/>')
    if kind == "สี่เหลี่ยมจัตุรัส":
        return _svg(84, 84, f'<rect x="9" y="9" width="66" height="66" {st}/>')
    if kind == "สี่เหลี่ยมผืนผ้า":
        return _svg(100, 72, f'<rect x="8" y="14" width="84" height="46" {st}/>')
    if kind == "สี่เหลี่ยมด้านขนาน":
        return _svg(100, 72, f'<path d="M26 12 H94 L70 60 H2 Z" {st}/>')
    if kind == "ห้าเหลี่ยม":
        return _svg(88, 84, f'<path d="M44 6 L82 34 L68 78 H20 L6 34 Z" {st}/>')
    raise ValueError(kind)


SHAPE_OF = {"วงกลม": "วงกลม", "วงรี": "วงรี",
            "สามเหลี่ยม": "รูปสามเหลี่ยม", "สามเหลี่ยมมุมฉาก": "รูปสามเหลี่ยม",
            "สี่เหลี่ยมจัตุรัส": "รูปสี่เหลี่ยม",
            "สี่เหลี่ยมผืนผ้า": "รูปสี่เหลี่ยม",
            "สี่เหลี่ยมด้านขนาน": "รูปสี่เหลี่ยม"}


def figrow(cells, caption=""):
    """แถวรูป cells = [(svg, ป้ายใต้รูป), ...]"""
    figs = "".join(f'<div class="fig">{sv}{f"<b>{lb}</b>" if lb else ""}</div>'
                   for sv, lb in cells)
    cap = f'<div class="tag">{caption}</div>' if caption else ""
    return f'<div class="scene"><div class="row">{figs}</div>{cap}</div>'


def pickrow(items, caption=""):
    """แถวรูปติดป้าย ก ข ค ง ให้เด็กเลือก"""
    return figrow([(sv, lb) for sv, lb in items], caption)


# ───────────────────── แบบรูป (pattern) ─────────────────────

def patrow(cells, caption="แบบรูป"):
    """แถวแบบรูป ช่องที่เป็น None จะกลายเป็นกรอบว่างให้เด็กเติม"""
    out = []
    for c in cells:
        if c is None:
            out.append('<div class="fig"><span class="blankbox">?</span></div>')
        else:
            out.append(f'<div class="fig">{c}</div>')
    cap = f'<div class="tag">{caption}</div>' if caption else ""
    return (f'<div class="scene"><div class="row pat">{"".join(out)}</div>'
            f'{cap}</div>')


# ───────────────────── จำนวนนับ 21–100 ─────────────────────

def rod():
    """แท่งสิบ 1 แท่ง = 10 หน่วย"""
    cells = "".join(f'<rect x="3" y="{3 + i * 9}" width="16" height="9" '
                    f'fill="{SOFT}" stroke="{EDGE}" stroke-width="1.2"/>'
                    for i in range(10))
    return _svg(22, 96, cells, "rod")


def unit():
    return _svg(20, 20, f'<rect x="2.5" y="2.5" width="15" height="15" '
                        f'fill="{SOFT2}" stroke="{EDGE}" stroke-width="1.2"/>',
                "unit")


def basetens(n, caption=""):
    """รูปแท่งสิบกับลูกบาศก์หน่วย แสดงจำนวน n"""
    t, o = divmod(n, 10)
    rods = "".join(f'<span class="bt">{rod()}</span>' for _ in range(t))
    units = "".join(f'<span class="bu">{unit()}</span>' for _ in range(o))
    cap = f'<div class="tag">{caption}</div>' if caption else ""
    return (f'<div class="scene"><div class="base10">{rods}'
            f'<span class="ones">{units}</span></div>{cap}</div>')


def numline(lo, hi, marks=(), step=1, caption=""):
    """เส้นจำนวน marks = ตำแหน่งที่ให้เว้นว่างเป็นกล่อง ?"""
    n = (hi - lo) // step
    w, pad = 660, 26
    gap = (w - pad * 2) / n
    body = [f'<line x1="{pad}" y1="40" x2="{w - pad}" y2="40" '
            f'stroke="{INK}" stroke-width="2"/>']
    for i in range(n + 1):
        x = pad + gap * i
        v = lo + step * i
        body.append(f'<line x1="{x:.1f}" y1="32" x2="{x:.1f}" y2="48" '
                    f'stroke="{INK}" stroke-width="2"/>')
        if v in marks:
            body.append(f'<rect x="{x - 16:.1f}" y="56" width="32" height="26" '
                        f'rx="5" fill="#fff" stroke="{EDGE}" '
                        f'stroke-width="1.8"/>')
            body.append(f'<text x="{x:.1f}" y="75" text-anchor="middle" '
                        f'font-size="15" fill="{EDGE}">?</text>')
        else:
            body.append(f'<text x="{x:.1f}" y="74" text-anchor="middle" '
                        f'font-size="15" fill="{INK}">{v}</text>')
    cap = f'<div class="tag">{caption}</div>' if caption else ""
    return (f'<div class="scene">{_svg(w, 88, "".join(body), "nl")}{cap}</div>')


# ───────────────────── การวัดความยาว ─────────────────────

def ruler(cm, label="", obj=None):
    """ไม้บรรทัดยาว cm ช่อง ถ้าใส่ obj จะวาดแท่งสิ่งของทาบไว้ด้านบน"""
    unit_w, pad = 26, 20
    w = pad * 2 + unit_w * cm
    body = [f'<rect x="{pad}" y="34" width="{unit_w * cm}" height="30" '
            f'fill="{SOFT}" stroke="{INK}" stroke-width="1.8"/>']
    for i in range(cm + 1):
        x = pad + unit_w * i
        body.append(f'<line x1="{x}" y1="34" x2="{x}" y2="{50 if i % 5 else 58}" '
                    f'stroke="{INK}" stroke-width="1.4"/>')
        if i % 5 == 0:
            body.append(f'<text x="{x}" y="76" text-anchor="middle" '
                        f'font-size="13" fill="{INK}">{i}</text>')
    if obj:
        ln, col = obj
        body.append(f'<rect x="{pad}" y="8" width="{unit_w * ln}" height="18" '
                    f'rx="4" fill="{col}" stroke="{INK}" stroke-width="1.6"/>')
    cap = f'<div class="tag">{label}</div>' if label else ""
    return f'<div class="scene">{_svg(w, 86, "".join(body), "rl")}{cap}</div>'


def bar(cm, col=SOFT2, label=""):
    """แท่งสิ่งของยาว cm ช่อง ไม่มีไม้บรรทัด ใช้เปรียบเทียบความยาว"""
    unit_w = 17
    w = unit_w * cm + 10
    body = (f'<rect x="5" y="4" width="{unit_w * cm}" height="17" rx="4" '
            f'fill="{col}" stroke="{INK}" stroke-width="1.6"/>')
    lb = f'<b>{label}</b>' if label else ""
    return f'<div class="fig">{_svg(w, 26, body, "br")}{lb}</div>'


C_WARM, C_COOL, C_LEAF, C_ROSE = SOFT2, SOFT, "#eef7ea", "#fbeaf0"


def tower(cm, col=SOFT, label="", unit_h=10):
    """แท่งแนวตั้งใช้เปรียบเทียบความสูง สูง cm ช่อง"""
    h = unit_h * cm + 12
    body = (f'<rect x="5" y="{h - unit_h * cm - 5}" width="36" '
            f'height="{unit_h * cm}" rx="4" fill="{col}" stroke="{INK}" '
            f'stroke-width="1.8"/>')
    lb = f"<b>{label}</b>" if label else ""
    return f'<div class="fig">{_svg(46, h, body, "tw")}{lb}</div>'


def towerrow(towers, caption=""):
    cap = f'<div class="tag">{caption}</div>' if caption else ""
    return (f'<div class="scene"><div class="row tws">{"".join(towers)}</div>'
            f'{cap}</div>')


def barrow(bars, caption=""):
    cap = f'<div class="tag">{caption}</div>' if caption else ""
    return (f'<div class="scene"><div class="bars">{"".join(bars)}</div>'
            f'{cap}</div>')


# ───────────────────── การบวกลบแนวตั้ง ─────────────────────

def vsum(a, b, op="+", ans=False):
    """โจทย์บวก/ลบแนวตั้ง ถ้า ans=True จะใส่คำตอบให้ด้วย"""
    r = a + b if op == "+" else a - b
    cells = (f'<tr><td class="o"></td><td>{a // 10 or "&nbsp;"}</td>'
             f'<td>{a % 10}</td></tr>'
             f'<tr><td class="o">{op}</td><td>{b // 10 or "&nbsp;"}</td>'
             f'<td>{b % 10}</td></tr>')
    bot = (f'<tr class="sum"><td></td><td>{r // 10 or "&nbsp;"}</td>'
           f'<td>{r % 10}</td></tr>' if ans else
           '<tr class="sum"><td></td><td>&nbsp;</td><td>&nbsp;</td></tr>')
    return f'<table class="vs">{cells}{bot}</table>'


def vsrow(items, ans=False):
    """แถวโจทย์แนวตั้งหลายข้อ items = [(a, b, op), ...]"""
    cells = "".join(f'<div class="fig">{vsum(a, b, op, ans)}</div>'
                    for a, b, op in items)
    return f'<div class="scene"><div class="row vsr">{cells}</div></div>'


TH_ONES = ["", "หนึ่ง", "สอง", "สาม", "สี่", "ห้า", "หก", "เจ็ด", "แปด", "เก้า"]
TH_TENS = ["", "สิบ", "ยี่สิบ", "สามสิบ", "สี่สิบ", "ห้าสิบ", "หกสิบ",
           "เจ็ดสิบ", "แปดสิบ", "เก้าสิบ"]


def thword(n):
    """ตัวหนังสือแสดงจำนวนนับ 1–100 ตามการอ่านแบบไทย"""
    if n == 100:
        return "หนึ่งร้อย"
    t, o = divmod(n, 10)
    if t == 0:
        return TH_ONES[o]
    return TH_TENS[t] + ("เอ็ด" if o == 1 else TH_ONES[o])


def chart(start, end, blanks=(), cols=10, caption=""):
    """ตารางจำนวน ช่องที่อยู่ใน blanks จะเว้นว่างให้เด็กเติม"""
    cells, row = [], []
    for v in range(start, end + 1):
        row.append('<td class="bl">&nbsp;</td>' if v in blanks
                   else f"<td>{v}</td>")
        if len(row) == cols:
            cells.append("<tr>" + "".join(row) + "</tr>")
            row = []
    if row:
        cells.append("<tr>" + "".join(row) + "</tr>")
    cap = f'<div class="tag">{caption}</div>' if caption else ""
    return (f'<div class="scene"><table class="nchart">{"".join(cells)}'
            f'</table>{cap}</div>')


def mixrow(cells, caption=""):
    """กองรูปขนาดเล็กหลายรูป ให้เด็กนับแยกชนิด"""
    cap = f'<div class="tag">{caption}</div>' if caption else ""
    return (f'<div class="scene"><div class="mix">{"".join(cells)}</div>'
            f'{cap}</div>')


def pyramid(levels, caption=""):
    """บันไดบวก levels = [[ชั้นบนสุด], ..., [ชั้นล่างสุด]] ช่อง None = ให้เติม"""
    rows = []
    for lv in levels:
        cells = "".join(
            '<span class="pb blank">&nbsp;</span>' if v is None
            else f'<span class="pb">{v}</span>' for v in lv)
        rows.append(f'<div class="prow">{cells}</div>')
    cap = f'<div class="tag">{caption}</div>' if caption else ""
    return (f'<div class="scene"><div class="pyr">{"".join(rows)}</div>'
            f'{cap}</div>')


CSS_EXTRA = r"""
.pyr{display:inline-flex;flex-direction:column;align-items:center;gap:5px}
.prow{display:flex;gap:7px;justify-content:center}
.pb{display:inline-flex;width:52px;height:34px;border:1.5px solid #b9d2e0;
  border-radius:7px;background:#f4fafd;align-items:center;
  justify-content:center;font-size:13pt;font-weight:700;color:#13303f}
.pb.blank{background:#fff;border:1.8px solid #0A5680}
.steps{margin-top:6px}
.steps .st{font-size:11.5pt;color:#2b4b5c;padding:2px 0 2px 4px;
  line-height:2}
.pic{vertical-align:middle}
.mix{display:flex;flex-wrap:wrap;justify-content:center;
  align-items:center;gap:9px 14px;padding:0 8px}
.mix svg{height:44px;width:auto}
.row.sm svg{height:52px;width:auto}
.row.pat{gap:10px}
.blankbox{display:inline-flex;width:62px;height:62px;border:2.2px dashed #0A5680;
  border-radius:10px;align-items:center;justify-content:center;
  font-size:22pt;color:#0A5680;background:#fff}
.base10{display:flex;align-items:flex-end;justify-content:center;gap:7px;
  flex-wrap:wrap}
.base10 .ones{display:flex;align-items:flex-end;flex-wrap:wrap;
  width:64px;gap:2px}
.bars{display:flex;flex-direction:column;align-items:flex-start;gap:2px;
  padding-left:10px}
.bars .fig{display:flex;align-items:center;gap:9px;text-align:left}
.bars .fig b{display:inline;font-size:11pt}
table.vs{border-collapse:collapse;margin:0 auto;font-size:17pt;font-weight:700;
  color:#13303f}
table.vs td{width:27px;height:28px;text-align:center;padding:0 2px}
table.vs td.o{width:22px;color:#b4471f}
table.vs tr.sum td{border-top:2.2px solid #13303f}
.row.vsr{gap:26px;align-items:flex-start}
table.nchart{border-collapse:collapse;margin:4px auto}
table.nchart td{border:1.2px solid #b9d2e0;width:50px;height:30px;
  text-align:center;font-size:12pt;color:#13303f}
table.nchart td.bl{background:#fff;border:1.8px solid #0A5680}
.row.tws{align-items:flex-end;gap:18px}
.row.tws .fig b{display:block;font-size:11pt;margin-top:3px}
"""
