# -*- coding: utf-8 -*-
"""สร้าง PDF ทั้งหมดของบทที่ 14 โจทย์ปัญหาการบวก และโจทย์ปัญหาการลบ"""
import pathlib
import sys

HERE = pathlib.Path(__file__).parent
sys.path.insert(0, str(HERE.parent))
sys.path.insert(0, str(HERE))

import engine                                         # noqa: E402
import exams                                          # noqa: E402
import sheets                                         # noqa: E402

CH = "บทที่ 14 โจทย์ปัญหาการบวก และโจทย์ปัญหาการลบ"
SCOPE = ("แสดงวิธีหาคำตอบของโจทย์ปัญหาการบวกและการลบจำนวนนับไม่เกิน 100 และ 0")

if __name__ == "__main__":
    engine.run(HERE, CH, "MathP1_C14", SCOPE, sheets, exams)
